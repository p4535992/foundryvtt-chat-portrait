import type { ImageReplaceVoiceData } from "../ChatPortraitModels";

export default {
	SYSTEM_ID: "",
	imageReplacerDamageType: <ImageReplaceVoiceData[]>[],
	imageReplacerWeaponProperties: <ImageReplaceVoiceData[]>[],
	imageReplacerIconizer: <ImageReplaceVoiceData[]>[]
};

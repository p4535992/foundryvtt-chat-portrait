import type { ImageReplaceVoiceData } from "../ChatPortraitModels";

export default {
	SYSTEM_ID: "swade",
	imageReplacerDamageType: <ImageReplaceVoiceData[]>[],
	imageReplacerWeaponProperties: <ImageReplaceVoiceData[]>[],
	imageReplacerIconizer: <ImageReplaceVoiceData[]>[]
};
